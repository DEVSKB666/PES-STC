
import { defineStore } from 'pinia'
export const useAuthStore = defineStore('auth', {
  state: ()=> ({ token: localStorage.getItem('token')||'', name: localStorage.getItem('name')||'', role: localStorage.getItem('role')||'', email: localStorage.getItem('email')||'' }),
  getters: {
    isHR: (s)=> s.role==='ฝ่ายบริหารบุคลากร',
    isCommittee: (s)=> s.role==='คณะกรรมการประเมิน',
    isEvaluated: (s)=> s.role==='ผู้รับการประเมิน',
  },
  actions: {
    setUser(u){ this.name=u.name; this.role=u.role; this.email=u.email; localStorage.setItem('name',u.name); localStorage.setItem('role',u.role); localStorage.setItem('email',u.email) },
    async login(email, password){
      const r=await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})})
      const j=await r.json().catch(()=>null); if(!r.ok) throw new Error(j?.message||'Login failed')
      this.token=j.data.token; localStorage.setItem('token',this.token); this.setUser(j.data.user)
      return true
    },
    async register(payload){
      const r=await fetch('/api/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})
      const j=await r.json().catch(()=>null); if(!r.ok) throw new Error(j?.message||'Register failed'); return true
    },
    async reset(email,new_password){
      const r=await fetch('/api/auth/reset',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,new_password})})
      const j=await r.json().catch(()=>null); if(!r.ok) throw new Error(j?.message||'Reset failed'); return true
    },
    logout(){ this.token=''; this.name=''; this.role=''; this.email=''; localStorage.clear(); location.href='/login' },
    authHeader(){ return this.token? {Authorization:'Bearer '+this.token}:{ } }
  }
})
