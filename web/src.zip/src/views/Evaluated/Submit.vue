
<template>
  <div class="space-y-4">
    <h2 class="text-xl font-bold">ส่งคะแนนตนเอง</h2>
    <div class="card grid md:grid-cols-3 gap-3">
      <input v-model.number="cycle_id" class="input" type="number" placeholder="cycle_id"/>
      <input v-model.number="indicator_id" class="input" type="number" placeholder="indicator_id"/>
      <input v-model.number="self_score" class="input" type="number" min="1" max="4" placeholder="คะแนน"/>
      <input v-model="evidence_url" class="input md:col-span-2" placeholder="evidence URL (ถ้ามี)"/>
      <button class="btn" @click="submit">ส่ง</button>
      <p v-if="msg" class="text-green-600 text-sm">{{msg}}</p>
    </div>
  </div>
</template>
<script setup>
import { ref } from 'vue'
import { useAuthStore } from '../../store/auth'
const auth=useAuthStore()
const cycle_id=ref(1); const indicator_id=ref(1); const self_score=ref(3); const evidence_url=ref(''); const msg=ref('')
const submit=async()=>{ const r=await fetch('/api/evaluated/submit',{method:'POST',headers:{...auth.authHeader(),'Content-Type':'application/json'},body:JSON.stringify({cycle_id,indicator_id,self_score,evidence_url})}); const j=await r.json().catch(()=>null); msg.value=j?.message||(r.ok?'OK':'Error') }
</script>
