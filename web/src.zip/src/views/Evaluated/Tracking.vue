
<template>
  <div class="space-y-4">
    <h2 class="text-xl font-bold">ติดตาม (ฉัน)</h2>
    <div class="card">
      <div>ส่งแล้ว: <b>{{data.submitted}}</b> / ทั้งหมด: <b>{{data.total}}</b></div>
      <div class="w-full bg-gray-200 h-2 rounded mt-2">
        <div class="bg-indigo-600 h-2 rounded" :style="{width: (data.submitted*100/Math.max(1,data.total)) + '%'}"></div>
      </div>
    </div>
  </div>
</template>
<script setup>
import { ref, onMounted } from 'vue'
import { useAuthStore } from '../../store/auth'
const auth=useAuthStore(); const data=ref({total:0,submitted:0})
const load=async()=>{ const r=await fetch('/api/evaluated/progress?cycle_id=1',{headers:auth.authHeader()}); const j=await r.json(); data.value=j.data||{total:0,submitted:0} }
onMounted(load)
</script>
