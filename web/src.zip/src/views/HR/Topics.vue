<template>
  <div class="space-y-4">
    <h2 class="text-xl font-bold">หัวข้อการประเมิน (HR)</h2>
    <div class="card grid md:grid-cols-3 gap-3">
      <input v-model="name" class="input" placeholder="ชื่อหัวข้อ" />
      <input v-model="description" class="input" placeholder="รายละเอียด" />
      <button class="btn" @click="add">เพิ่ม</button>
    </div>
    <div class="relative overflow-x-auto rounded-lg shadow-md">
      <table class="w-full text-sm text-left text-gray-700">
        <thead
          class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-white"
        >
          <tr>
            <th scope="col" class="px-6 py-3">ID</th>
            <th scope="col" class="px-6 py-3">ชื่อ</th>
            <th scope="col" class="px-6 py-3">รายละเอียด</th>
            <th scope="col" class="px-6 py-3">Action</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="t in list"
            :key="t.id"
            class="bg-white border-b hover:bg-gray-50 transition"
          >
            <td class="px-6 py-4">{{ t.id }}</td>
            <td class="px-6 py-4">{{ t.name }}</td>
            <td class="px-6 py-4">{{ t.description }}</td>
            <td class="px-6 py-4">
              <a
                href="#"
                class="inline-block px-3 py-1 text-xs font-semibold text-white bg-red-600 rounded-lg hover:bg-blue-100 transition"
                >ลบ</a
              >
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
<script setup>
import { ref, onMounted } from 'vue';
import { useAuthStore } from '../../store/auth';
const auth = useAuthStore();
const list = ref([]);
const name = ref('');
const description = ref('');
const load = async () => {
  const r = await fetch('/api/common/topics', { headers: auth.authHeader() });
  const j = await r.json();
  list.value = j.data || [];
};
const add = async () => {
  await fetch('/api/hr/topics', {
    method: 'POST',
    headers: { ...auth.authHeader(), 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, description }),
  });
  name.value = '';
  description.value = '';
  load();
};
onMounted(load);
</script>
