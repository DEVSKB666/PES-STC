<template>
  <div class="space-y-4">
    <h2 class="text-xl font-bold">รายงาน & สถิติ (HR)</h2>

    <!-- Vertical column chart -->
    <div class="card p-4">
      <div class="text-sm text-gray-600 mb-3">
        ค่าเฉลี่ย/สูงสุด/ต่ำสุด + คะแนนรวมถ่วงน้ำหนัก (รอบ 1)
      </div>

      <div v-if="rows.length" class="space-y-3">
        <div class="text-xs text-gray-500 mb-2">
          คอลัมน์ = Total weighted score (normalized)
        </div>

        <!-- horizontal scroll container so many columns fit -->
        <div class="overflow-x-auto">
          <div class="flex items-end gap-4 px-2 py-4" style="min-height: 220px">
            <div
              v-for="r in rows"
              :key="r.user_id"
              class="flex flex-col items-center w-28"
              :title="`${r.name} — total: ${fmt(r.total_weighted)} / avg: ${fmt(
                r.avg_score
              )}`"
            >
              <!-- value badge -->
              <div class="text-xs text-gray-700 mb-2 tabular-nums">
                {{ fmt(r.total_weighted) }}
              </div>

              <!-- bar wrapper -->
              <div
                class="w-full bg-gray-100 rounded-t-md overflow-hidden flex items-end"
                style="height: 160px"
              >
                <div
                  class="w-full bg-gradient-to-t from-indigo-600 to-blue-400 transition-height duration-400"
                  :style="{ height: columnHeight(r.total_weighted) }"
                ></div>
              </div>

              <!-- label -->
              <div
                class="mt-2 w-full text-xs text-center text-gray-700 truncate"
                style="line-height: 1.1rem"
              >
                {{ r.name }}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div v-else class="py-6 text-center text-gray-500">
        กำลังโหลดข้อมูลหรือยังไม่มีข้อมูล
      </div>
    </div>

    <!-- Table (kept for exact values) -->
    <div class="card p-4 overflow-x-auto">
      <table class="w-full text-sm">
        <thead>
          <tr class="text-left text-xs text-gray-600">
            <th class="py-2">ผู้รับการประเมิน</th>
            <th class="py-2">Avg</th>
            <th class="py-2">Min</th>
            <th class="py-2">Max</th>
            <th class="py-2">Total</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in rows" :key="r.user_id" class="border-t">
            <td class="py-2">{{ r.name }}</td>
            <td class="py-2">{{ fmt(r.avg_score) }}</td>
            <td class="py-2">{{ fmt(r.min_score) }}</td>
            <td class="py-2">{{ fmt(r.max_score) }}</td>
            <td class="py-2">{{ fmt(r.total_weighted) }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useAuthStore } from '../../store/auth';

const auth = useAuthStore();
const rows = ref([]);

const fmt = (n) => (n == null ? '-' : Number(n).toFixed(2));

const load = async () => {
  try {
    const res = await fetch('/api/hr/stats/overview?cycle_id=1', {
      headers: auth.authHeader(),
    });
    if (!res.ok) return;
    const j = await res.json();
    rows.value = j.data || [];
  } catch (e) {
    console.error(e);
  }
};

onMounted(load);

// compute max value (use total_weighted fallback to avg if missing)
const maxValue = computed(() => {
  let max = 0;
  for (const r of rows.value) {
    const v = Number(r.total_weighted ?? r.avg_score ?? 0) || 0;
    if (v > max) max = v;
  }
  return max;
});

// return CSS height string like '60%'
const columnHeight = (val) => {
  const n = Number(val ?? 0) || 0;
  const max = maxValue.value || 0;
  if (max === 0) return '6%'; // small visible column when all zeros/undefined
  const pct = Math.round((n / max) * 100);
  // ensure minimum visible height for very small values
  return `${Math.max(6, pct)}%`;
};
</script>

<style scoped>
.card {
  background: white;
  border-radius: 0.5rem;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
}
.transition-height {
  transition: height 0.35s ease;
}
/* use transition on custom class */
.transition-height,
.transition-height > div {
  transition: height 0.35s ease, background 0.25s ease;
}
/* smoothing for gradient bar */
.bg-gradient-to-t {
  background-image: linear-gradient(
    180deg,
    rgba(99, 102, 241, 1),
    rgba(59, 130, 246, 1)
  );
}
.tabular-nums {
  font-variant-numeric: tabular-nums;
}
</style>
