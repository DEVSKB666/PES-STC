<template>
  <div class="space-y-4">
    <h2 class="text-xl font-bold">การมอบหมาย (HR)</h2>
    <div class="card grid md:grid-cols-4 gap-3">
      <input
        v-model.number="cycle_id"
        class="input"
        type="number"
        placeholder="cycle_id"
      />
      <input
        v-model.number="evaluated_id"
        class="input"
        type="number"
        placeholder="evaluated_id"
      />
      <input
        v-model.number="committee_id"
        class="input"
        type="number"
        placeholder="committee_id"
      />
      <button class="btn" @click="add">มอบหมาย</button>
    </div>
    <div class="card">
      <table class="w-full text-sm">
        <thead>
          <tr class="text-left">
            <th>ID</th>
            <th>รอบ</th>
            <th>ผู้รับการประเมิน</th>
            <th>กรรมการ</th>
            <th>สถานะ</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="a in list" :key="a.id" class="border-t">
            <td class="py-2">{{ a.id }}</td>
            <td>{{ a.cycle_id }}</td>
            <td>{{ a.evaluated_name }}</td>
            <td>{{ a.committee_name }}</td>
            <td>{{ a.status }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
<script setup>
import { ref, onMounted } from 'vue';
import { useAuthStore } from '../../store/auth';
const auth = useAuthStore();
const list = ref([]);
const cycle_id = ref(1);
const evaluated_id = ref();
const committee_id = ref();
const load = async () => {
  const r = await fetch('/api/hr/assignments', { headers: auth.authHeader() });
  const j = await r.json();
  list.value = j.data || [];
};
const add = async () => {
  const payload = {
    cycle_id: Number(cycle_id.value),
    evaluated_id:
      evaluated_id.value == null ? null : Number(evaluated_id.value),
    committee_id:
      committee_id.value == null ? null : Number(committee_id.value),
  };

  try {
    const r = await fetch('/api/hr/assignments', {
      method: 'POST',
      headers: { ...auth.authHeader(), 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!r.ok) {
      const text = await r.text().catch(() => 'server error');
      alert('ตรวจสอบ ID หรือข้อผิดพลาด: ' + text);
      return;
    }

    // รีโหลดรายการและรีเซ็ตฟอร์ม
    await load();
    evaluated_id.value = undefined;
    committee_id.value = undefined;
  } catch (e) {
    console.error(e);
    alert('เกิดข้อผิดพลาดในการส่งข้อมูล');
  }
};
onMounted(load);
</script>
