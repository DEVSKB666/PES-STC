
<template>
  <div class="min-h-[70vh] flex items-center justify-center p-4">
    <div class="w-full max-w-md">
      <div class="text-center mb-6">
        <div class="text-3xl font-extrabold text-indigo-700">PES Plus</div>
        <div class="text-sm text-gray-600">ระบบประเมินบุคลากร 68-70</div>
      </div>
      <div class="card space-y-3">
        <h1 class="text-xl font-semibold text-center">เข้าสู่ระบบ</h1>
        <input v-model="email" class="input" placeholder="อีเมล" />
        <input v-model="password" class="input" type="password" placeholder="รหัสผ่าน" />
        <button class="btn w-full" @click="go">เข้าสู่ระบบ</button>
        <p v-if="err" class="text-rose-600 text-sm text-center">{{err}}</p>
        <div class="flex items-center justify-between text-sm">
          <router-link class="link" to="/register">สมัครสมาชิก</router-link>
          <router-link class="link" to="/reset">ลืมรหัสผ่าน?</router-link>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup>
import { ref } from 'vue'
import { useAuthStore } from '../../store/auth'
const auth=useAuthStore()
const email=ref('hr@demo.local')
const password=ref('123456')
const err=ref('')
const go=async()=>{ try{ err.value=''; await auth.login(email.value,password.value); location.href='/' }catch(e){ err.value=e.message } }
</script>
