
<template>
  <div class="space-y-4">
    <h2 class="text-xl font-bold">คิวงานของกรรมการ</h2>
    <div class="card">
      <table class="w-full text-sm">
        <thead><tr class="text-left">
          <th>Submission</th><th>ผู้รับการประเมิน</th><th>ตัวชี้วัด</th><th>Self</th><th>หลักฐาน</th><th></th>
        </tr></thead>
        <tbody>
          <tr v-for="r in rows" :key="r.submission_id" class="border-t">
            <td class="py-2">#{{r.submission_id}}</td>
            <td>{{r.evaluated_name}}</td>
            <td>{{r.indicator_title}}</td>
            <td>{{r.self_score}}</td>
            <td><a v-if="r.evidence_path" :href="fileUrl(r.evidence_path)" class="link" target="_blank">ไฟล์</a></td>
            <td><router-link class="link" :to="{path:'/committee/review', query:{ id:r.submission_id }}">รีวิว</router-link></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
<script setup>
import { ref, onMounted } from 'vue'
import { useAuthStore } from '../../store/auth'
const auth=useAuthStore(); const rows=ref([])
const fileUrl=(p)=> p?.startsWith('http')? p : '/uploads/'+(p||'').replace(/^\+/,'')
const load=async()=>{ const r=await fetch('/api/committee/queue',{headers:auth.authHeader()}); const j=await r.json(); rows.value=j.data||[] }
onMounted(load)
</script>
