<template>
  <div class="min-h-screen">
    <NavBar />
    <main class="max-w-6xl mx-auto p-4 md:p-6 md:ml-64">
      <router-view />
    </main>
  </div>
</template>
<script setup>
import NavBar from './components/NavBar.vue';
</script>
