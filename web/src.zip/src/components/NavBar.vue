<template>
  <header
    class="md:hidden bg-white/80 backdrop-blur sticky top-0 z-50 border-b"
  >
    <div class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <button
          class="p-2 rounded-md hover:bg-gray-100"
          @click="sidebarOpen = true"
          aria-label="Open menu"
        >
          <svg
            class="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M4 6h16M4 12h16M4 18h16"
            />
          </svg>
        </button>
        <router-link to="/" class="font-bold text-lg text-indigo-700"
          >PES Plus</router-link
        >
      </div>

      <div class="text-sm" v-if="auth.token">👤 {{ auth.name }}</div>
    </div>
  </header>

  <aside
    class="hidden md:fixed md:top-0 md:left-0 md:flex md:flex-col md:w-64 md:h-screen bg-white/95 backdrop-blur border-r shadow-sm md:z-40"
  >
    <div class="px-6 py-6 flex items-center justify-between">
      <router-link to="/" class="font-bold text-lg text-indigo-700"
        >PES Plus</router-link
      >
      <button class="text-sm bg-red-600 p-2 text-white rounded-lg" v-if="auth.token" @click="handleLogout">
        ออกจากระบบ
      </button>
    </div>

        <div class="px-6 py-4 border-t text-sm">
      <div v-if="auth.token">
        <div class="py-2 bg-black text-white px-3 rounded-lg mb-3">
          👤 : {{ auth.name }}
        </div>
        <span class="kpi">{{ auth.role }}</span>
      </div>
      <div v-else class="flex gap-3">
        <router-link to="/login" class="underline">เข้าสู่ระบบ</router-link>
        <router-link to="/register" class="underline">สมัคร</router-link>
      </div>
    </div>

    <nav class="px-4 py-2 flex-1 overflow-y-auto">
      <ul class="flex flex-col gap-2 text-sm">
        <li v-if="auth.isHR">
          <router-link
            to="/hr/topics"
            class="block px-3 py-2 rounded hover:bg-indigo-50"
            >หัวข้อ</router-link
          >
        </li>
        <li v-if="auth.isHR">
          <router-link
            to="/hr/indicators"
            class="block px-3 py-2 rounded hover:bg-indigo-50"
            >ตัวชี้วัด</router-link
          >
        </li>
        <li v-if="auth.isHR">
          <router-link
            to="/hr/cycles"
            class="block px-3 py-2 rounded hover:bg-indigo-50"
            >รอบ</router-link
          >
        </li>
        <li v-if="auth.isHR">
          <router-link
            to="/hr/assignments"
            class="block px-3 py-2 rounded hover:bg-indigo-50"
            >มอบหมาย</router-link
          >
        </li>
        <li v-if="auth.isCommittee">
          <router-link
            to="/committee/queue"
            class="block px-3 py-2 rounded hover:bg-indigo-50"
            >คิวกรรมการ</router-link
          >
        </li>
        <li v-if="auth.isCommittee">
          <router-link
            to="/committee/review"
            class="block px-3 py-2 rounded hover:bg-indigo-50"
            >รีวิว</router-link
          >
        </li>
        <li v-if="auth.isEvaluated">
          <router-link
            to="/evaluated/submit"
            class="block px-3 py-2 rounded hover:bg-indigo-50"
            >ส่งงาน</router-link
          >
        </li>
        <li>
          <router-link
            to="/evaluated/tracking"
            class="block px-3 py-2 rounded hover:bg-indigo-50"
            >ติดตาม</router-link
          >
        </li>
        <li v-if="auth.isHR">
          <router-link
            to="/hr/reports"
            class="block px-3 py-2 rounded hover:bg-indigo-50"
            >รายงาน</router-link
          >
        </li>
      </ul>
    </nav>

  </aside>

  <!-- Mobile sliding sidebar -->
  <transition name="slide">
    <div v-if="sidebarOpen" class="fixed inset-0 z-50 md:hidden">
      <div
        class="absolute inset-0 bg-black/40"
        @click="sidebarOpen = false"
      ></div>

      <aside
        class="absolute left-0 top-0 bottom-0 w-72 bg-white/95 backdrop-blur shadow-lg flex flex-col"
      >
        <div class="px-4 py-4 flex items-center justify-between border-b">
          <router-link to="/" class="font-bold text-indigo-700"
            >PES Plus</router-link
          >
          <button
            class="p-2 rounded-md hover:bg-gray-100"
            @click="sidebarOpen = false"
            aria-label="Close menu"
          >
            <svg
              class="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        <nav class="px-4 py-3 flex-1 overflow-y-auto">
          <ul class="flex flex-col gap-2 text-sm">
            <li v-if="auth.isHR">
              <router-link
                @click="closeMobile"
                to="/hr/topics"
                class="block px-3 py-2 rounded hover:bg-indigo-50"
                >หัวข้อ</router-link
              >
            </li>
            <li v-if="auth.isHR">
              <router-link
                @click="closeMobile"
                to="/hr/indicators"
                class="block px-3 py-2 rounded hover:bg-indigo-50"
                >ตัวชี้วัด</router-link
              >
            </li>
            <li v-if="auth.isHR">
              <router-link
                @click="closeMobile"
                to="/hr/cycles"
                class="block px-3 py-2 rounded hover:bg-indigo-50"
                >รอบ</router-link
              >
            </li>
            <li v-if="auth.isHR">
              <router-link
                @click="closeMobile"
                to="/hr/assignments"
                class="block px-3 py-2 rounded hover:bg-indigo-50"
                >มอบหมาย</router-link
              >
            </li>
            <li v-if="auth.isCommittee">
              <router-link
                @click="closeMobile"
                to="/committee/queue"
                class="block px-3 py-2 rounded hover:bg-indigo-50"
                >คิวกรรมการ</router-link
              >
            </li>
            <li v-if="auth.isCommittee">
              <router-link
                @click="closeMobile"
                to="/committee/review"
                class="block px-3 py-2 rounded hover:bg-indigo-50"
                >รีวิว</router-link
              >
            </li>
            <li v-if="auth.isEvaluated">
              <router-link
                @click="closeMobile"
                to="/evaluated/submit"
                class="block px-3 py-2 rounded hover:bg-indigo-50"
                >ส่งงาน</router-link
              >
            </li>
            <li>
              <router-link
                @click="closeMobile"
                to="/evaluated/tracking"
                class="block px-3 py-2 rounded hover:bg-indigo-50"
                >ติดตาม</router-link
              >
            </li>
            <li v-if="auth.isHR">
              <router-link
                @click="closeMobile"
                to="/hr/reports"
                class="block px-3 py-2 rounded hover:bg-indigo-50"
                >รายงาน</router-link
              >
            </li>
          </ul>
        </nav>

        <div class="px-4 py-4 border-t text-sm">
          <div v-if="auth.token" class="mb-2">
            👤 {{ auth.name }} · <span class="kpi">{{ auth.role }}</span>
          </div>
          <div class="flex gap-3">
            <button v-if="auth.token" class="underline" @click="handleLogout">
              ออกจากระบบ
            </button>

            <template v-else>
              <router-link @click="closeMobile" to="/login" class="underline"
                >เข้าสู่ระบบ</router-link
              >
              <router-link @click="closeMobile" to="/register" class="underline"
                >สมัคร</router-link
              >
            </template>
          </div>
        </div>
      </aside>
    </div>
  </transition>
</template>

<script setup>
import { ref, watch } from 'vue';
import { useRoute } from 'vue-router';
import { useAuthStore } from '../store/auth';

const auth = useAuthStore();
const sidebarOpen = ref(false);
const route = useRoute();

function closeMobile() {
  sidebarOpen.value = false;
}

function handleLogout() {
  sidebarOpen.value = false;
  auth.logout();
}

// ปิด sidebar บนมือถือเมื่อ route เปลี่ยน
watch(
  () => route.fullPath,
  () => {
    sidebarOpen.value = false;
  }
);
</script>

<style scoped>


</style>
